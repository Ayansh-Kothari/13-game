import random

# 1. Rock, Paper, Scissors (console)
def rock_paper_scissors():
    choices = ['rock', 'paper', 'scissors']
    print("\nWelcome to Rock, Paper, Scissors!")
    while True:
        user = input("Choose rock, paper, or scissors (or 'quit' to return to menu): ").lower()
        if user == 'quit':
            print("Returning to main menu...\n")
            break
        if user not in choices:
            print("Invalid choice. Please try again.")
            continue
        computer = random.choice(choices)
        print(f"Computer chose: {computer}")
        if user == computer:
            print("It's a tie!\n")
        elif (
            (user == 'rock' and computer == 'scissors') or
            (user == 'paper' and computer == 'rock') or
            (user == 'scissors' and computer == 'paper')
        ):
            print("You win!\n")
        else:
            print("You lose!\n")

# 2. Snake (pygame)
def snake():
    try:
        import pygame
        pygame.init()
        width, height = 400, 400
        block = 20
        screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption('Snake')
        font = pygame.font.SysFont(None, 35)
        clock = pygame.time.Clock()

        def draw_snake(snake_blocks):
            for x, y in snake_blocks:
                pygame.draw.rect(screen, (0, 255, 0), [x, y, block, block])

        def message(msg, color):
            text = font.render(msg, True, color)
            screen.blit(text, [width / 10, height / 3])

        def game_loop():
            game_over = False
            game_close = False
            x = width // 2
            y = height // 2
            x_change = 0
            y_change = 0
            snake_blocks = []
            snake_len = 1
            food_x = round(random.randrange(0, width - block) / block) * block
            food_y = round(random.randrange(0, height - block) / block) * block

            while not game_over:
                while game_close:
                    screen.fill((0, 0, 0))
                    message("You lost! Press C to play again or M for menu.", (255, 0, 0))
                    pygame.display.update()
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            return
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_c:
                                game_loop()
                                return
                            if event.key == pygame.K_m:
                                pygame.quit()
                                return
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        return
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_LEFT:
                            x_change = -block
                            y_change = 0
                        elif event.key == pygame.K_RIGHT:
                            x_change = block
                            y_change = 0
                        elif event.key == pygame.K_UP:
                            y_change = -block
                            x_change = 0
                        elif event.key == pygame.K_DOWN:
                            y_change = block
                            x_change = 0

                if x >= width or x < 0 or y >= height or y < 0:
                    game_close = True

                x += x_change
                y += y_change

                screen.fill((0, 0, 0))
                pygame.draw.rect(screen, (255, 0, 0), [food_x, food_y, block, block])
                snake_blocks.append([x, y])
                if len(snake_blocks) > snake_len:
                    del snake_blocks[0]

                for block_xy in snake_blocks[:-1]:
                    if block_xy == [x, y]:
                        game_close = True

                draw_snake(snake_blocks)
                pygame.display.update()

                if x == food_x and y == food_y:
                    food_x = round(random.randrange(0, width - block) / block) * block
                    food_y = round(random.randrange(0, height - block) / block) * block
                    snake_len += 1

                clock.tick(10)

            pygame.quit()
            print("Returning to main menu...\n")

        game_loop()

    except ImportError:
        print("pygame is not installed. Please install it by running 'pip install pygame' in the terminal.\n")

# 3. Guess the Number (console)
def guess_the_number():
    number = random.randint(1, 100)
    attempts = 0
    print("\nWelcome to Guess the Number (1-100)!")
    while True:
        guess = input("Your guess (or 'quit' to return to menu): ")
        if guess.lower() == 'quit':
            print("Returning to main menu...\n")
            break
        if not guess.isdigit():
            print("Please enter a valid number.")
            continue
        guess = int(guess)
        attempts += 1
        if guess < number:
            print("Too low!")
        elif guess > number:
            print("Too high!")
        else:
            print(f"Correct! You got it in {attempts} tries.\n")
            break

# 4. Hangman (pygame)
def hangman():
    import pygame, random
    WIDTH, HEIGHT = 900, 600
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Hangman')
    clock = pygame.time.Clock()
    WHITE, BLACK = (255, 255, 255), (0, 0, 0)
    font = pygame.font.SysFont('consolas', 32)

    # Categories: Edit or expand as you like!
    categories = {
    "Animals": [
        "dog","cat","lion","tiger","bear","wolf","fox","rabbit","deer","horse","zebra","monkey","gorilla","leopard","jaguar","cheetah","hyena","otter","mole","rat",
        "mouse","shrew","bat","pig","goat","sheep","cow","buffalo","bison","yak","camel","llama","alpaca","giraffe","hippo","rhino","elephant","antelope","gazelle","ibex",
        "kangaroo","koala","wombat","platypus","hedgehog","porcupine","squirrel","chipmunk","beaver","badger","skunk","raccoon","weasel","ferret","walrus","seal","orca",
        "dolphin","whale","shark","trout","salmon","eel","cod","bass","carp","tuna","stingray","octopus","squid","lobster","crab","shrimp","clam","oyster","snail","slug",
        "earthworm","centipede","millipede","bee","wasp","ant","termite","fly","mosquito","butterfly","moth","dragonfly","grasshopper","locust","caterpillar","ladybug","spider"
    ],
    "Birds": [
        "sparrow","robin","crow","magpie","eagle","hawk","falcon","owl","dove","pigeon","parrot","macaw","cockatoo","finch","wren","heron","crane","stork","pelican","albatross",
        "swallow","swift","kite","vulture","kingfisher","woodpecker","jay","oriole","nightingale","lark","cuckoo","quail","pheasant","partridge","ostrich","emu","kiwi","penguin",
        "flamingo","goose","duck","swan","gull","tern","loon","sandpiper","plover","lapwing","curlew","ibis","bustard","toucan","hornbill","babbler","sunbird","weaver","vireo",
        "thrush","pipit","shrike","starling","bulbul","roller","bee-eater","drongo","wagtail","flycatcher","redstart","warbler","chat","swamphen","rail","crake","coot","grebe",
        "petrel","shearwater","gannet","auk","razorbill","puffin","snipe","woodcock","ptarmigan","capercaillie","grouse","blackbird","rook","jackdaw","chough","cormorant","bittern",
        "egret","spoonbill","avocet","pratincole","skua","phalarope"
    ],
    "Countries": [
        "canada","brazil","france","china","india","japan","russia","spain","germany","italy","mexico","argentina","chile","egypt","nigeria","kenya","australia","newzealand",
        "indonesia","malaysia","singapore","vietnam","thailand","sweden","norway","finland","iceland","ireland","denmark","netherlands","poland","switzerland","austria",
        "greece","turkey","saudiarabia","iran","iraq","syria","jordan","lebanon","israel","pakistan","bangladesh","afghanistan","nepal","bhutan","srilanka","maldives",
        "madagascar","ethiopia","tanzania","uganda","southafrica","zimbabwe","botswana","namibia","morocco","algeria","tunisia","libya","sudan","angola","zambia","ghana",
        "cameroon","senegal","cotedivoire","mali","niger","chad","somalia","burundi","rwanda","mozambique","gabon","congo","lesotho","swaziland","eritrea","djibouti","guinea",
        "benin","togo","sierra","gambia","mauritania","equatorialguinea","centralafricanrepublic","southsudan","burkinafaso","liberia","seychelles","capeverde","sudan"
    ],
    "Sports": [
        "soccer","football","basketball","baseball","tennis","cricket","rugby","golf","hockey","volleyball","badminton","tabletennis","pingpong","squash","handball",
        "cycling","swimming","boxing","wrestling","karate","judo","taekwondo","gymnastics","fencing","archery","rowing","canoeing","kayaking","sailing","diving","surfing",
        "skiing","snowboarding","icehockey","figureskating","speedskating","luge","bobsleigh","curling","biathlon","triathlon","pentathlon","decathlon","track","marathon",
        "sprint","relay","polevault","longjump","highjump","shotput","discus","javelin","hammerthrow","weightlifting","powerlifting","bodybuilding","skateboarding",
        "rollerblading","mountainbiking","bmx","motocross","carracing","kartracing","rally","nascar","formulaone","dragracing","horseracing","showjumping","equestrian",
        "polo","croquet","bowling","darts","snooker","billiards","pool","bridge","chess","checkers","go","backgammon","mahjong","poker","blackjack","roulette","craps",
        "lottery","bingo","keno","dominoes","tictactoe"
    ],
    "Planets": [
        "mercury","venus","earth","mars","jupiter","saturn","uranus","neptune","pluto","ceres","eris","haumea","makemake","io","europa","ganymede","callisto","titania",
        "oberon","umbriel","ariel","miranda","triton","proteus","nereid","charon","styx","nix","hydra","kerberos","dysnomia","orcus","quaoar","sedna","varuna","ixion",
        "salacia","huya","varda","albion","pallas","juno","vesta","hygiea","euphrosyne","psyche","interamnia","davida","cybele","eos","eurydome","helike","pasiphae",
        "sinope","carme","ananke","leda","thebe","amalthea","metis","adrastea","callirrhoe","autonoe","hermippe","thyone","iocaste","mneme","harpalyke","praline",
        "orthosie","euanthe","carpo","erinome","aitne","kallichore","chaldene","isonoe","dia","elara","lysithea","praxidike","kale","hegemone","titan","hyperion",
        "iapetus","phoebe","janus","epimetheus","mimas"
    ],
    "Foods": [
        "apple","banana","orange","grape","watermelon","pear","peach","plum","apricot","kiwi","mango","papaya","pineapple","lemon","lime","cherry","strawberry",
        "raspberry","blueberry","blackberry","grapefruit","melon","cantaloupe","honeydew","fig","date","persimmon","pomegranate","guava","lychee","dragonfruit",
        "starfruit","jackfruit","durian","passionfruit","avocado","coconut","olive","tomato","potato","carrot","onion","garlic","pepper","chili","cucumber",
        "zucchini","eggplant","squash","pumpkin","corn","peas","bean","lentil","chickpea","cabbage","broccoli","cauliflower","lettuce","spinach","kale",
        "collard","celery","asparagus","artichoke","turnip","parsnip","rutabaga","radish","beet","leek","fennel","bokchoy","chard","brusselsprout","mushroom",
        "truffle","shallot","scallion","ginger","turmeric","basil","thyme","rosemary","parsley","cilantro","sage","oregano","mint"
    ],
    "Gadgets": [
        "phone","laptop","tablet","smartwatch","camera","headphones","keyboard","mouse","monitor","printer","scanner","modem","router","speaker","microphone",
        "webcam","projector","joystick","gamepad","console","drone","gps","calculator","flashdrive","memorycard","harddrive","ssd","bluetooth","charger",
        "adapter","cable","remote","alarmclock","radio","walkman","pager","typewriter","dictaphone","fax","television","notebook","smarttv","fitnessband",
        "thermometer","toaster","microwave","fridge","freezer","oven","stove","dishwasher","vacuum","fan","ac","humidifier","dehumidifier","hairdryer",
        "shaver","epilator","iron","blender","mixer","juicer","coffee","kettle","ricecooker","breadmaker","slowcooker","pressurecooker","airfryer","grill",
        "sandwichmaker","waterfilter","purifier","heater","humidistat","ereader","usb","pen","stylus","smartpen","camcorder","polaroid","headset","earbuds",
        "soundbar","smartlight","drill","multitool"
    ],
    "Jobs": [
        "teacher","doctor","nurse","engineer","scientist","pilot","chef","baker","firefighter","police","lawyer","judge","artist","musician","actor","director",
        "author","writer","editor","publisher","driver","farmer","gardener","veterinarian","mechanic","carpenter","plumber","electrician","technician","programmer",
        "designer","architect","accountant","banker","manager","receptionist","clerk","cashier","butcher","tailor","waiter","waitress","bartender","host","hostess",
        "cleaner","maid","janitor","guard","soldier","general","admiral","captain","officer","detective","spy","agent","priest","monk","nun","bishop","pope","rabbi",
        "imam","minister","counselor","coach","athlete","dancer","singer","composer","conductor","painter","sculptor","potter","weaver","smith","mason","miner",
        "pilot","sailor","fisherman","hunter","trapper","explorer","astronaut","chemist","physicist"
    ],
    "Plants": [
        "rose","tulip","orchid","sunflower","daisy","lily","daffodil","hyacinth","peony","chrysanthemum","lavender","violet","iris","crocus","azalea","magnolia",
        "camellia","rhododendron","pansy","marigold","zinnia","petunia","snapdragon","salvia","begonia","geranium","fuchsia","lobelia","cyclamen","delphinium",
        "foxglove","hollyhock","larkspur","poppy","primrose","veronica","alyssum","phlox","aster","anemone","ranunculus","columbine","calendula","clematis",
        "heather","honeysuckle","jasmine","sweetpea","nasturtium","cosmos","dahlia","scabiosa","statice","tansy","camomile","bachelorbutton","coreopsis",
        "crinum","freesia","gardenia","impatiens","liatris","lupine","mallow","monarda","nigella","osteospermum","penstemon","plumbago","saxifrage","sedum",
        "verbena","yarrow","alstroemeria","bouvardia","calla","fritillaria","kniphofia","muscari","nemesia","saponaria","silene","spiraea","streptocarpus",
        "tithonia","tuberose","trollius","viburnum","yucca","zenobia"
    ],
    "Instruments": [
        "piano","guitar","violin","cello","bass","drum","trumpet","trombone","clarinet","flute","saxophone","oboe","bassoon","harp","banjo","mandolin","ukulele",
        "accordion","harmonica","xylophone","marimba","timpani","triangle","tambourine","cymbal","gong","castanet","bagpipe","organ","synthesizer","melodica",
        "lute","sitar","tabla","djembe","conga","bongo","tuba","euphonium","baritone","cornet","piccolo","englishhorn","recorder","panpipes","ocarina","didgeridoo",
        "dulcimer","zither","balalaika","santoor","sarod","shehnai","veena","oud","kanun","koto","shamisen","erhu","guqin","pipa","gayageum","yangqin","hang",
        "steelpan","kalimba","mbira","vibraphone","glassharmonica","celesta","ondeviole","hurdygurdy","sousaphone","washboard","jawharp","bones","claves","cabasa",
        "agogo","shekere","cuica","cowbell","guiro","talkingdrum","vuvuzela"
    ],
    "Colors": [
        "red","blue","green","yellow","orange","purple","violet","indigo","black","white","gray","brown","tan","maroon","magenta","turquoise","teal","aqua","cyan",
        "lime","olive","navy","gold","silver","bronze","coral","peach","beige","ivory","mustard","plum","lavender","jade","mint","periwinkle","salmon","ruby","amber",
        "emerald","sapphire","topaz","garnet","opal","aquamarine","chartreuse","cerulean","copper","eggshell","fuchsia","khaki","lemon","mauve","ochre","rose","sand",
        "scarlet","sepia","slate","taupe","umber","vermilion","wisteria","alabaster","amaranth","asparagus","auburn","azure","bisque","bistre","blush","bole","buff",
        "byzantium","celadon","chestnut","cinnabar","citrine","claret","cobalt","cream","crimson","ebony","ecru","feldgrau","fern","flax","gamboge","ginger","glaucous",
        "heliotrope","honeydew"
    ],
    "Cities": [
        "tokyo","delhi","shanghai","mumbai","sao paulo","beijing","cairo","dhaka","mexicocity","osaka","karachi","chongqing","istanbul","buenosaires","kolkata","lagos",
        "manila","rio","guangzhou","lahore","shenzhen","bengaluru","moscow","paris","london","bangkok","hyderabad","chennai","tehran","bogota","jakarta","lima","hongkong",
        "hochi minh","karaj","ahmedabad","kuala lumpur","nairobi","sydney","rome","melbourne","berlin","cape town","barcelona","madrid","boston","newyork","chicago",
        "losangeles","houston","miami","toronto","montreal","vancouver","calgary","ottawa","washington","seattle","philadelphia","sanfrancisco","atlanta","phoenix",
        "dallas","detroit","denver","orlando","san diego","tampa","minneapolis","honolulu","cleveland","pittsburgh","st louis","cincinnati","baltimore","portland",
        "saltlakecity","indianapolis","kansas city","columbus","charlotte","sacramento","milwaukee","neworleans","richmond","raleigh","nashville","austin","jacksonville",
        "san jose"
    ],
    "Rivers": [
        "nile","amazon","yangtze","mississippi","yenisei","yellow","ob","parana","congo","amur","lena","mekong","mackenzie","niger","tocantins","sao francisco","danube",
        "urumqi","loire","elbe","rhine","volga","dnieper","ganges","indus","brahmaputra","magdalena","salween","irrawaddy","orinoco","yakima","fraser","murray","darling",
        "tigris","euphrates","jordan","thames","seine","spree","elbe","weser","po","tagus","guadiana","duero","rhone","tiber","tarn","volta","ogun","benue","senegal",
        "congo","kasai","gambia","zambezi","limpopo","orange","okavango","sava","drava","soča","marne","maritsa","nezhegol","arno","garonne","aare","inn","saône",
        "doubs","lot","dordogne","isère","loiret","somme","vire","aude","var","herault","tarn","arn","cher","creuse","sarthe","vegre","mayenne","bida"
    ],
    "Mountains": [
        "everest","k2","kangchenjunga","lhotse","makalu","cho oyu","dhaulagiri","manaslu","nanga parbat","annapurna","gasherbrum","broad peak","shishapangma","gyachung kang",
        "masherbrum","distaghil sar","ngadi chuli","khunyang chhish","manaslu","himalchuli","distaghil sar","ngadi chuli","khunyang chhish","saser kangri","jasper peak",
        "langtang lirung","gangapurna","turkestan","gongga shan","king's peak","mount st elias","mount fairweather","denali","logan","saint elias","lucania","steele",
        "wood","alaska","mckinley","foraker","saint elias","hubley","mather","athabasca","assiniboine","baker","barbeau","bearhat","bigelow","blackburn","blanc",
        "borah","breithorn","bross","buckner","buachaille","castle","clark","columbia","comox","cook","craig","crestone","crowsnest","damavand","dana","darran",
        "dhaulagiri","dickerson","dome","donard","elbert","elliott","emma","emmons","etna","evans","evarts","fairfield","fremont","gannett","garibaldi","gibbs","glacier"
    ],
    "Oceans": [
        "pacific","atlantic","indian","southern","arctic","mediterranean","caribbean","bering","gulf of mexico","sea of japan","baltic","north sea","red sea","black sea",
        "caspian sea","adriatic","aegean","ionian","arabian","andaman","banda","barents","beaufort","bellingshausen","bismarck","bohai","chukchi","coral","cosmonaut",
        "east china","east siberian","flores","greenland","hudson bay","java","kars","laptev","lazarev","lincoln","molucca","okhotsk","philippine","rose","sargasso",
        "scotia","sibuyan","solomon","tasman","timor","weddell","white","yellow sea","lamancha","bay of biscay","irish sea","tasman sea","gulf of guinea","mozambique",
        "persian gulf","gulf of oman","gulf of aden","lake victoria","lake tanganyika","lake baikal","lake superior","lake huron","lake michigan","lake erie","lake ontario",
        "lake chad","lake titicaca","lake malawi","dead sea","aral sea","lake geneva","lake constance","lake ladoga","lake onega","lake van","lake sevan","lake tana",
        "lake nasser","lake albert","lake edward"
    ],
    "Islands": [
        "greenland","new guinea","borneo","madagascar","baffin","sumatra","honshu","victoria","great britain","ellesmere","sulawesi","south island","java","north island",
        "luzon","newfoundland","cuba","iceland","mindanao","ireland","sakhalin","hispaniola","hokkaido","haiti","taiwan","new britain","new ireland","new caledonia",
        "tasmania","sardinia","sicily","kola","new zealand","new georgia","new hanover","new guinea","new hebrides","new ireland","new jersey","new south wales",
        "newfoundland","niue","norderney","norfolk","norfolk island","norfolk islands","north island","northumberland","novaya zemlya","oahu","okinoerabu","okinawa",
        "oregon","palawan","palmyra","panglao","pantelleria","paracel","paros","parry","philippines","pitcairn","ponza","prince edward","prince of wales","puerto rico",
        "raiatea","rakino","rambouillet","redonda","reunion","rodrigues","ruapuke","saaremaa","saipan","samar","samos","santa cruz","sardinia","savai'i","scilly",
        "seram","severnaya zemlya","sheppey","shikoku","sjaelland"
    ],
    "Languages": [
        "english","spanish","french","german","italian","portuguese","russian","mandarin","cantonese","arabic","hindi","bengali","punjabi","japanese","korean",
        "vietnamese","thai","turkish","persian","urdu","malay","swahili","dutch","greek","hebrew","polish","czech","slovak","hungarian","romanian","bulgarian",
        "croatian","serbian","bosnian","slovenian","albanian","estonian","latvian","lithuanian","finnish","norwegian","danish","swedish","icelandic","irish",
        "welsh","scottish","cornish","breton","armenian","georgian","kazakh","uzbek","turkmen","kyrgyz","tajik","mongolian","tibetan","burmese","khmer","lao",
        "nepali","sinhalese","maldivian","pashto","kurdish","syriac","aramaic","coptic","basque","catalan","galician","asturian","occitan","faroese","manx",
        "sami","luxembourgish","malagasy","maori","samoan","tongan","hawaiian","fijian","gilbertese","marshallese","palauan"
    ],

}

    def draw_text(text, x, y, size=10, color=BLACK):
        f = pygame.font.SysFont("consolas", size)
        screen.blit(f.render(text, True, color), (x, y))

    def draw_hangman(wrong):
        base_x, base_y = 700, 500
        if wrong > 0: pygame.draw.circle(screen, BLACK, (base_x, base_y - 150), 25, 3)
        if wrong > 1: pygame.draw.line(screen, BLACK, (base_x, base_y - 125), (base_x, base_y - 80), 3)
        if wrong > 2: pygame.draw.line(screen, BLACK, (base_x, base_y - 110), (base_x - 30, base_y - 50), 3)
        if wrong > 3: pygame.draw.line(screen, BLACK, (base_x, base_y - 110), (base_x + 30, base_y - 50), 3)
        if wrong > 4: pygame.draw.line(screen, BLACK, (base_x, base_y - 80), (base_x - 30, base_y - 20), 3)
        if wrong > 5: pygame.draw.line(screen, BLACK, (base_x, base_y - 80), (base_x + 30, base_y - 20), 3)

    # Main game loop
    running = True
    while running:
        # --- Category select ---
        category_keys = list(categories.keys())
        selection = 0
        selecting = True
        while selecting:
            screen.fill(WHITE)
            draw_text("Select a category (UP/DOWN + ENTER, ESC for menu):", 40, 50, 28)
            for idx, cat in enumerate(category_keys):
                color = (0, 100, 200) if idx == selection else BLACK
                draw_text(f"{idx+1}. {cat}", 70, 120 + 20*idx, 20, color)
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP and selection > 0:
                        selection -= 1
                    elif event.key == pygame.K_DOWN and selection < len(category_keys) - 1:
                        selection += 1
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        selecting = False
                    elif event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return
        category = category_keys[selection]
        word = random.choice(categories[category]).lower()
        guessed = set()
        wrong = set()
        tries = 6

        # --- Game Loop ---
        guessing = True
        while guessing:
            screen.fill(WHITE)
            draw_text(f"Category: {category}", 40, 40, 32)
            display = " ".join([c if c in guessed else "_" for c in word])
            draw_text("Word: " + display, 40, 100, 38)
            draw_text(f"Wrong: {' '.join(sorted(wrong))}", 40, 180, 30, (180,0,0))
            draw_text(f"Tries left: {tries}", 40, 220, 30, (180,0,0))
            draw_hangman(len(wrong))

            if all(c in guessed for c in word):
                draw_text("🎉 You Win! Press ESC for menu.", 40, 300, 34, (0,128,0))
                pygame.display.flip()
                win = True
                waiting = True
                while waiting:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            return
                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                pygame.quit()
                                print("Returning to main menu...\n")
                                return
                            if event.key == pygame.K_RETURN:
                                waiting = False
                break

            if tries == 0:
                draw_text(f"You Lose! Word was: {word}", 40, 300, 34, (200,0,0))
                draw_text("Press ESC for menu.", 40, 350, 28, (100,100,100))
                pygame.display.flip()
                waiting = True
                while waiting:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            return
                        elif event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                pygame.quit()
                                print("Returning to main menu...\n")
                                return
                            if event.key == pygame.K_RETURN:
                                waiting = False
                break

            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return
                    elif pygame.K_a <= event.key <= pygame.K_z:
                        ch = chr(event.key)
                        if ch in guessed or ch in wrong:
                            continue
                        if ch in word:
                            guessed.add(ch)
                        else:
                            wrong.add(ch)
                            tries -= 1

# 5. Tic Tac Toe (console)
def tic_tac_toe():
    print("\nTic Tac Toe!")
    board = [" " for _ in range(9)]
    def print_board():
        for i in range(3):
            print(" | ".join(board[3*i:3*i+3]))
            if i < 2:
                print("--+---+--")
    def check_winner(player):
        wins = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        return any(all(board[i] == player for i in line) for line in wins)
    current = "X"
    moves = 0
    while True:
        print_board()
        move = input(f"Player {current}, enter 1-9 or 'quit': ")
        if move.lower() == 'quit':
            print("Returning to main menu...\n")
            break
        if not move.isdigit() or not (1 <= int(move) <= 9):
            print("Invalid move. Try again.")
            continue
        idx = int(move) - 1
        if board[idx] != " ":
            print("That spot is taken.")
            continue
        board[idx] = current
        moves += 1
        if check_winner(current):
            print_board()
            print(f"Player {current} wins!\n")
            break
        if moves == 9:
            print_board()
            print("It's a draw!\n")
            break
        current = "O" if current == "X" else "X"

# 6. Math Quiz (console)
def math_quiz():
    print("\nWelcome to Math Quiz!")
    score = 0
    for i in range(5):
        a = random.randint(2, 1000)
        b = random.randint(2, 1000)
        op = random.choice(['+', '-',])
        if op == '+':
            answer = a + b
        elif op == '-':
            answer = a - b
        else:
            answer = a * b
        user = input(f"Q{i+1}: {a} {op} {b} = ")
        if user.strip() == str(answer):
            print("Correct!\n")
            score += 1
        else:
            print(f"Wrong! The answer was {answer}.\n")
    print(f"Quiz complete! Your score: {score}/5\nReturning to main menu...\n")

# 7. Coin Toss (console)
def coin_toss():
    print("\nCoin Toss! Guess heads or tails.")
    score = 0
    for i in range(5):
        guess = input(f"Round {i+1} - Your guess (heads/tails): ").lower()
        if guess not in ['heads', 'tails']:
            print("Invalid. Skipping round.")
            continue
        result = random.choice(['heads', 'tails'])
        print(f"It was {result}!")
        if guess == result:
            print("You guessed right!")
            score += 1
        else:
            print("Wrong guess.")
    print(f"You got {score}/5 correct.\n")

# 8. Flappy Bird (pygame)
def flappy_bird():
    try:
        import pygame
        pygame.init()
        WIDTH, HEIGHT = 400, 600
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Flappy Bird')
        clock = pygame.time.Clock()
        font = pygame.font.SysFont(None, 36)

        bird_x = 100
        bird_y = HEIGHT // 2
        bird_vel = 0
        gravity = 0.5
        flap_power = -8
        pipe_width = 60
        pipe_gap = 180
        pipe_vel = 3
        pipes = []
        score = 0

        def new_pipe():
            y = random.randint(100, HEIGHT - pipe_gap - 100)
            return [WIDTH, y]

        pipes.append(new_pipe())
        game_over = False

        while not game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        bird_vel = flap_power
                    if event.key == pygame.K_m:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return

            bird_vel += gravity
            bird_y += bird_vel

            # Pipe movement
            for pipe in pipes:
                pipe[0] -= pipe_vel
            if pipes[-1][0] < WIDTH // 2:
                pipes.append(new_pipe())
            if pipes[0][0] < -pipe_width:
                pipes.pop(0)
                score += 1

            # Collision detection
            for pipe_x, pipe_y in pipes:
                if bird_x + 30 > pipe_x and bird_x < pipe_x + pipe_width:
                    if bird_y < pipe_y or bird_y > pipe_y + pipe_gap:
                        game_over = True

            if bird_y < 0 or bird_y > HEIGHT - 30:
                game_over = True

            # Drawing
            screen.fill((135, 206, 250))
            pygame.draw.ellipse(screen, (255, 255, 0), (bird_x, int(bird_y), 30, 30))
            for pipe_x, pipe_y in pipes:
                pygame.draw.rect(screen, (0, 200, 0), (pipe_x, 0, pipe_width, pipe_y))
                pygame.draw.rect(screen, (0, 200, 0), (pipe_x, pipe_y + pipe_gap, pipe_width, HEIGHT - pipe_y - pipe_gap))
            score_surface = font.render(f"Score: {score}", True, (0, 0, 0))
            screen.blit(score_surface, (10, 10))

            pygame.display.flip()
            clock.tick(60)

        # Game over screen
        screen.fill((0, 0, 0))
        over_surface = font.render("Game Over!", True, (255, 0, 0))
        screen.blit(over_surface, (WIDTH//2 - 80, HEIGHT//2 - 50))
        score_surface = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_surface, (WIDTH//2 - 60, HEIGHT//2))
        pygame.display.flip()
        pygame.time.wait(2000)
        pygame.quit()
        print("Returning to main menu...\n")
        return

    except ImportError:
        print("pygame is not installed. Please run 'pip install pygame' to play Flappy Bird.\n")
        return
def tetris():
    try:
        import pygame
        import random

        pygame.init()
        WIDTH, HEIGHT = 300, 600
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Tetris")
        clock = pygame.time.Clock()
        font = pygame.font.SysFont(None, 36)

        ROWS, COLS = 20, 10
        BLOCK_SIZE = WIDTH // COLS

        SHAPES = [
            [[1,1,1,1]],              # I
            [[1,1],[1,1]],            # O
            [[0,1,0],[1,1,1]],        # T
            [[1,0,0],[1,1,1]],        # J
            [[0,0,1],[1,1,1]],        # L
            [[1,1,0],[0,1,1]],        # S
            [[0,1,1],[1,1,0]]         # Z
        ]

        COLORS = [
            (0, 255, 255),  # I - cyan
            (255, 255, 0),  # O - yellow
            (128, 0, 128),  # T - purple
            (0, 0, 255),    # J - blue
            (255, 165, 0),  # L - orange
            (0, 255, 0),    # S - green
            (255, 0, 0)     # Z - red
        ]

        class Piece:
            def __init__(self, shape_idx):
                self.shape = SHAPES[shape_idx]
                self.color = COLORS[shape_idx]
                self.x = COLS // 2 - len(self.shape[0]) // 2
                self.y = 0

            def rotate(self):
                self.shape = [list(row) for row in zip(*self.shape[::-1])]

        def create_grid(locked_positions={}):
            grid = [[(0,0,0) for _ in range(COLS)] for _ in range(ROWS)]
            for (x, y), color in locked_positions.items():
                if y > -1:
                    grid[y][x] = color
            return grid

        def valid_space(piece, grid):
            for y, row in enumerate(piece.shape):
                for x, cell in enumerate(row):
                    if cell:
                        px = piece.x + x
                        py = piece.y + y
                        if px < 0 or px >= COLS or py >= ROWS:
                            return False
                        if py > -1 and grid[py][px] != (0,0,0):
                            return False
            return True

        def clear_rows(grid, locked):
            rows_to_clear = []
            for y in range(ROWS-1, -1, -1):
                if (0,0,0) not in grid[y]:
                    rows_to_clear.append(y)
            for y in rows_to_clear:
                for x in range(COLS):
                    try:
                        del locked[(x,y)]
                    except KeyError:
                        continue
            if rows_to_clear:
                rows_to_clear.sort()
                for y in reversed(range(rows_to_clear[0])):
                    for x in range(COLS):
                        if (x, y) in locked:
                            color = locked.pop((x,y))
                            locked[(x, y + len(rows_to_clear))] = color
            return len(rows_to_clear)

        locked_positions = {}
        change_piece = False
        current_piece = Piece(random.randint(0, len(SHAPES)-1))
        next_piece = Piece(random.randint(0, len(SHAPES)-1))
        fall_time = 0
        fall_speed = 0.5
        level = 1
        score = 0

        running = True
        while running:
            grid = create_grid(locked_positions)
            fall_time += clock.get_rawtime()
            clock.tick()

            if fall_time/1000 > fall_speed:
                fall_time = 0
                current_piece.y += 1
                if not valid_space(current_piece, grid) and current_piece.y > 0:
                    current_piece.y -= 1
                    change_piece = True

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        current_piece.x -= 1
                        if not valid_space(current_piece, grid):
                            current_piece.x += 1
                    elif event.key == pygame.K_RIGHT:
                        current_piece.x += 1
                        if not valid_space(current_piece, grid):
                            current_piece.x -= 1
                    elif event.key == pygame.K_DOWN:
                        current_piece.y += 1
                        if not valid_space(current_piece, grid):
                            current_piece.y -= 1
                    elif event.key == pygame.K_UP:
                        current_piece.rotate()
                        if not valid_space(current_piece, grid):
                            # rotate back if invalid
                            for _ in range(3):
                                current_piece.rotate()
                    elif event.key == pygame.K_m:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return

            # Add piece to grid for drawing
            for y, row in enumerate(current_piece.shape):
                for x, cell in enumerate(row):
                    if cell:
                        px = current_piece.x + x
                        py = current_piece.y + y
                        if py > -1:
                            grid[py][px] = current_piece.color

            if change_piece:
                for y, row in enumerate(current_piece.shape):
                    for x, cell in enumerate(row):
                        if cell:
                            locked_positions[(current_piece.x + x, current_piece.y + y)] = current_piece.color
                current_piece = next_piece
                next_piece = Piece(random.randint(0, len(SHAPES)-1))
                change_piece = False
                cleared = clear_rows(grid, locked_positions)
                if cleared > 0:
                    score += cleared * 10
                    level = score // 100 + 1
                    fall_speed = max(0.1, 0.5 - (level - 1)*0.05)

            # Draw grid
            screen.fill((0,0,0))
            for y in range(ROWS):
                for x in range(COLS):
                    pygame.draw.rect(screen, grid[y][x], (x*BLOCK_SIZE, y*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 0)
                    pygame.draw.rect(screen, (40,40,40), (x*BLOCK_SIZE, y*BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE), 1)

            # Draw score and level
            score_text = font.render(f"Score: {score}", True, (255,255,255))
            screen.blit(score_text, (10,10))
            level_text = font.render(f"Level: {level}", True, (255,255,255))
            screen.blit(level_text, (10, 40))

            pygame.display.update()

            # Check game over
            for (x, y) in locked_positions:
                if y < 1:
                    screen.fill((0,0,0))
                    over_text = font.render("Game Over! Press M for menu", True, (255,0,0))
                    screen.blit(over_text, (20, HEIGHT//2 - 20))
                    pygame.display.flip()
                    waiting = True
                    while waiting:
                        for e in pygame.event.get():
                            if e.type == pygame.QUIT:
                                pygame.quit()
                                return
                            if e.type == pygame.KEYDOWN and e.key == pygame.K_m:
                                pygame.quit()
                                print("Returning to main menu...\n")
                                return

    except ImportError:
        print("pygame is not installed. Please run 'pip install pygame' to play Tetris.\n")
        return


def pacman():
    try:
        import pygame
        import math
        from collections import deque

        pygame.init()
        WIDTH, HEIGHT = 480, 480
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption('Pacman Improved')
        clock = pygame.time.Clock()
        font = pygame.font.SysFont(None, 36)

        TILE_SIZE = 24
        ROWS, COLS = HEIGHT // TILE_SIZE, WIDTH // TILE_SIZE

        # Maze: 1=wall, 0=path
        maze = [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,1],
            [1,0,1,0,1,0,1,1,1,1,0,1,0,1,0,1,0,1,0,1],
            [1,0,1,0,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1],
            [1,0,1,1,1,1,0,1,0,1,1,1,0,1,1,1,0,1,0,1],
            [1,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,1],
            [1,1,1,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,1],
            [1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1],
            [1,0,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
        ]
        ROWS = len(maze)
        COLS = len(maze[0])

        # Pellets positions: set of (x,y)
        pellets = set()
        for y in range(ROWS):
            for x in range(COLS):
                if maze[y][x] == 0:
                    pellets.add((x,y))

        class Entity:
            def __init__(self, x, y, color):
                self.x = x * TILE_SIZE + TILE_SIZE//2
                self.y = y * TILE_SIZE + TILE_SIZE//2
                self.grid_x = x
                self.grid_y = y
                self.color = color
                self.speed = 3  # pixels per frame
                self.dir_x = 0
                self.dir_y = 0

            def move(self):
                next_x = self.x + self.dir_x * self.speed
                next_y = self.y + self.dir_y * self.speed

                # Check collisions with walls
                if not is_wall_pixel(next_x, self.y):
                    self.x = next_x
                else:
                    self.dir_x = 0
                if not is_wall_pixel(self.x, next_y):
                    self.y = next_y
                else:
                    self.dir_y = 0

                # Update grid position for pellets & ghost AI
                self.grid_x = int(self.x // TILE_SIZE)
                self.grid_y = int(self.y // TILE_SIZE)

            def draw(self):
                pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), TILE_SIZE//2 - 2)

        def is_wall_pixel(px, py):
            # Return True if pixel at px, py is inside a wall tile
            grid_x = int(px // TILE_SIZE)
            grid_y = int(py // TILE_SIZE)
            if 0 <= grid_x < COLS and 0 <= grid_y < ROWS:
                return maze[grid_y][grid_x] == 1
            return True  # Outside maze treated as wall

        def draw_maze():
            for y, row in enumerate(maze):
                for x, tile in enumerate(row):
                    rect = pygame.Rect(x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    if tile == 1:
                        pygame.draw.rect(screen, (0, 0, 255), rect)  # Wall

        def draw_pellets():
            for (x,y) in pellets:
                pos = (x*TILE_SIZE + TILE_SIZE//2, y*TILE_SIZE + TILE_SIZE//2)
                pygame.draw.circle(screen, (255, 255, 0), pos, 5)

        def bfs(start, goal):
            # Simple BFS for ghost pathfinding on grid
            queue = deque([start])
            visited = {start: None}
            while queue:
                current = queue.popleft()
                if current == goal:
                    path = []
                    while current is not None:
                        path.append(current)
                        current = visited[current]
                    return path[::-1]
                x, y = current
                neighbors = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
                for nx, ny in neighbors:
                    if 0 <= nx < COLS and 0 <= ny < ROWS and maze[ny][nx] == 0:
                        if (nx, ny) not in visited:
                            visited[(nx, ny)] = current
                            queue.append((nx, ny))
            return []

        # Initialize entities
        pacman = Entity(1,1,(255, 255, 0))
        ghost = Entity(COLS-2, ROWS-2, (255, 0, 0))
        ghost.speed = 2

        score = 0
        game_over = False
        win = False

        while True:
            clock.tick(60)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        pacman.dir_x = -1
                        pacman.dir_y = 0
                    elif event.key == pygame.K_RIGHT:
                        pacman.dir_x = 1
                        pacman.dir_y = 0
                    elif event.key == pygame.K_UP:
                        pacman.dir_x = 0
                        pacman.dir_y = -1
                    elif event.key == pygame.K_DOWN:
                        pacman.dir_x = 0
                        pacman.dir_y = 1
                    elif event.key == pygame.K_m:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return

            if not game_over and not win:
                pacman.move()

                # Eat pellet if on pellet tile (allow some leniency with distance)
                pacman_pos = (pacman.grid_x, pacman.grid_y)
                if pacman_pos in pellets:
                    pellets.remove(pacman_pos)
                    score += 10
                    if not pellets:
                        win = True

                # Ghost AI: move toward Pacman using BFS path
                path = bfs((ghost.grid_x, ghost.grid_y), (pacman.grid_x, pacman.grid_y))
                if len(path) > 1:
                    next_cell = path[1]
                    dir_x = next_cell[0] - ghost.grid_x
                    dir_y = next_cell[1] - ghost.grid_y
                    ghost.dir_x = dir_x
                    ghost.dir_y = dir_y
                else:
                    ghost.dir_x = 0
                    ghost.dir_y = 0
                ghost.move()

                # Check collision with ghost
                dist = math.hypot(pacman.x - ghost.x, pacman.y - ghost.y)
                if dist < TILE_SIZE//1.5:
                    game_over = True

            # Draw everything
            screen.fill((0, 0, 0))
            draw_maze()
            draw_pellets()
            pacman.draw()
            ghost.draw()

            # Draw score
            score_text = font.render(f"Score: {score}", True, (255,255,255))
            screen.blit(score_text, (10, 10))

            if game_over:
                go_text = font.render("Game Over! Press M for menu", True, (255, 0, 0))
                screen.blit(go_text, (40, HEIGHT//2 - 20))
            elif win:
                win_text = font.render("You Win! Press M for menu", True, (0, 255, 0))
                screen.blit(win_text, (60, HEIGHT//2 - 20))

            pygame.display.flip()

    except ImportError:
        print("pygame is not installed. Please run 'pip install pygame' to play Pacman.\n")
        return

# Pong vs AI with balanced difficulty
def pong_vs_ai():
    import pygame
    import random

    pygame.init()
    WIDTH, HEIGHT = 600, 400
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pong vs AI")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 36)

    paddle_w, paddle_h = 10, 80
    ball_size = 15
    paddle_speed = 7
    ai_speed = 3  # Slower AI speed for fairness
    ai_error_chance = 0.3  # 30% chance AI skips moving (reaction delay)

    left_y = HEIGHT // 2 - paddle_h // 2
    right_y = HEIGHT // 2 - paddle_h // 2
    ball_x, ball_y = WIDTH // 2, HEIGHT // 2
    ball_speed_x = 5 * random.choice([-1, 1])
    ball_speed_y = 5 * random.choice([-1, 1])

    left_score = 0
    right_score = 0
    max_score = 5
    running = True

    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    pygame.quit()
                    print("Returning to main menu...\n")
                    return

        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and left_y > 0:
            left_y -= paddle_speed
        if keys[pygame.K_s] and left_y < HEIGHT - paddle_h:
            left_y += paddle_speed

        # AI paddle vertical movement with error chance
        import random
        if random.random() > ai_error_chance:
            if right_y + paddle_h/2 < ball_y and right_y < HEIGHT - paddle_h:
                right_y += ai_speed
            elif right_y + paddle_h/2 > ball_y and right_y > 0:
                right_y -= ai_speed

        ball_x += ball_speed_x
        ball_y += ball_speed_y

        if ball_y <= 0 or ball_y + ball_size >= HEIGHT:
            ball_speed_y *= -1

        left_rect = pygame.Rect(20, left_y, paddle_w, paddle_h)
        right_rect = pygame.Rect(WIDTH - 20 - paddle_w, right_y, paddle_w, paddle_h)
        ball_rect = pygame.Rect(ball_x, ball_y, ball_size, ball_size)

        if ball_rect.colliderect(left_rect) and ball_speed_x < 0:
            ball_speed_x *= -1
        if ball_rect.colliderect(right_rect) and ball_speed_x > 0:
            ball_speed_x *= -1

        if ball_x < 0:
            right_score += 1
            ball_x, ball_y = WIDTH // 2, HEIGHT // 2
            ball_speed_x = 5 * random.choice([-1, 1])
            ball_speed_y = 5 * random.choice([-1, 1])
        elif ball_x > WIDTH:
            left_score += 1
            ball_x, ball_y = WIDTH // 2, HEIGHT // 2
            ball_speed_x = 5 * random.choice([-1, 1])
            ball_speed_y = 5 * random.choice([-1, 1])

        screen.fill((0, 0, 0))
        pygame.draw.rect(screen, (255,255,255), left_rect)
        pygame.draw.rect(screen, (255,255,255), right_rect)
        pygame.draw.ellipse(screen, (255,255,255), ball_rect)

        score_text = font.render(f"{left_score} : {right_score}", True, (255,255,255))
        screen.blit(score_text, (WIDTH//2 - score_text.get_width()//2, 10))

        pygame.display.flip()

        if left_score >= max_score or right_score >= max_score:
            winner = "Player" if left_score > right_score else "AI"
            screen.fill((0,0,0))
            win_text = font.render(f"{winner} wins! Press M for menu", True, (255,255,0))
            screen.blit(win_text, (WIDTH//2 - win_text.get_width()//2, HEIGHT//2 - 20))
            pygame.display.flip()
            waiting = True
            while waiting:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        pygame.quit()
                        return
                    if e.type == pygame.KEYDOWN and e.key == pygame.K_m:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return

# Tennis vs AI with balanced difficulty and free paddle movement
def tennis_vs_ai():
    import pygame
    import random

    pygame.init()
    WIDTH, HEIGHT = 800, 500
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tennis vs AI")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 40)

    paddle_w, paddle_h = 12, 90
    ball_size = 18
    paddle_speed = 6
    ai_speed = 3  # Slower AI speed for fairness
    ai_error_chance = 0.3  # 30% chance AI skips moving

    # Initial paddle positions with horizontal freedom
    left_x = 20
    left_y = HEIGHT // 2 - paddle_h // 2
    right_x = WIDTH - 20 - paddle_w
    right_y = HEIGHT // 2 - paddle_h // 2

    ball_x, ball_y = WIDTH // 2, HEIGHT // 2
    ball_speed_x = 4 * random.choice([-1, 1])
    ball_speed_y = 4 * random.choice([-1, 1])

    left_score = 0
    right_score = 0
    max_score = 11

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    pygame.quit()
                    print("Returning to main menu...\n")
                    return

        keys = pygame.key.get_pressed()
        # Player vertical movement
        if keys[pygame.K_w] and left_y > 0:
            left_y -= paddle_speed
        if keys[pygame.K_s] and left_y < HEIGHT - paddle_h:
            left_y += paddle_speed
        # Player horizontal movement with limits (left half court)
        if keys[pygame.K_a] and left_x > 0:
            left_x -= paddle_speed
        if keys[pygame.K_d] and left_x < WIDTH // 2 - paddle_w:
            left_x += paddle_speed

        import random
        # AI paddle vertical movement with error chance
        if random.random() > ai_error_chance:
            if right_y + paddle_h / 2 < ball_y - 10 and right_y < HEIGHT - paddle_h:
                right_y += ai_speed
            elif right_y + paddle_h / 2 > ball_y + 10 and right_y > 0:
                right_y -= ai_speed
        # AI paddle horizontal movement with error chance
        if random.random() > ai_error_chance:
            if right_x + paddle_w / 2 < ball_x and right_x < WIDTH - paddle_w - 10:
                right_x += ai_speed
            elif right_x + paddle_w / 2 > ball_x and right_x > WIDTH // 2:
                right_x -= ai_speed

        # Move ball
        ball_x += ball_speed_x
        ball_y += ball_speed_y

        # Ball collision with top/bottom
        if ball_y <= 0 or ball_y + ball_size >= HEIGHT:
            ball_speed_y *= -1

        # Paddle rectangles
        left_rect = pygame.Rect(left_x, left_y, paddle_w, paddle_h)
        right_rect = pygame.Rect(right_x, right_y, paddle_w, paddle_h)
        ball_rect = pygame.Rect(ball_x, ball_y, ball_size, ball_size)

        # Ball collision with paddles
        if ball_rect.colliderect(left_rect) and ball_speed_x < 0:
            ball_speed_x *= -1
            # Add vertical deflection based on hit position
            ball_speed_y += (ball_y - (left_y + paddle_h / 2)) * 0.05
        if ball_rect.colliderect(right_rect) and ball_speed_x > 0:
            ball_speed_x *= -1
            ball_speed_y += (ball_y - (right_y + paddle_h / 2)) * 0.05

        # Scoring
        if ball_x < 0:
            right_score += 1
            ball_x, ball_y = WIDTH // 2, HEIGHT // 2
            ball_speed_x = 4 * random.choice([-1, 1])
            ball_speed_y = 4 * random.choice([-1, 1])
        elif ball_x > WIDTH:
            left_score += 1
            ball_x, ball_y = WIDTH // 2, HEIGHT // 2
            ball_speed_x = 4 * random.choice([-1, 1])
            ball_speed_y = 4 * random.choice([-1, 1])

        # Draw court and elements
        screen.fill((34, 139, 34))  # Tennis green background

        # Draw paddles and ball
        pygame.draw.rect(screen, (255, 255, 255), left_rect)
        pygame.draw.rect(screen, (255, 255, 255), right_rect)
        pygame.draw.ellipse(screen, (255, 255, 255), ball_rect)

        # Draw center net
        for y in range(0, HEIGHT, 20):
            pygame.draw.line(screen, (255, 255, 255), (WIDTH // 2, y), (WIDTH // 2, y + 10), 2)

        # Draw score
        score_text = font.render(f"{left_score} : {right_score}", True, (255, 255, 255))
        screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, 20))

        pygame.display.flip()

        # Check win
        if left_score >= max_score or right_score >= max_score:
            winner = "Player" if left_score > right_score else "AI"
            screen.fill((0, 0, 0))
            win_text = font.render(f"{winner} wins! Press M for menu", True, (255, 255, 0))
            screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, HEIGHT // 2 - 20))
            pygame.display.flip()
            waiting = True
            while waiting:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        pygame.quit()
                        return
                    if e.type == pygame.KEYDOWN and e.key == pygame.K_m:
                        pygame.quit()
                        print("Returning to main menu...\n")
                        return


# Updated Main menu
def main_menu():
    while True:
        print("==== Main Menu ====")
        print("1. Rock, Paper, Scissors")
        print("2. Snake")
        print("3. Guess the Number")
        print("4. Hangman")
        print("5. Tic Tac Toe")
        print("6. Math Quiz")
        print("7. Coin Toss")
        print("8. Flappy Bird")
        print("9. Pacman")
        print("10. Tetris")
        print("11. Pong vs AI")
        print("12. Tennis vs AI")
        print("13. Exit")
        choice = input("Choose a game (1-13): ").strip()
        if choice == '1':
            rock_paper_scissors()
        elif choice == '2':
            snake()
        elif choice == '3':
            guess_the_number()
        elif choice == '4':
            hangman()
        elif choice == '5':
            tic_tac_toe()
        elif choice == '6':
            math_quiz()
        elif choice == '7':
            coin_toss()
        elif choice == '8':
            flappy_bird()
        elif choice == '9':
            pacman()
        elif choice == '10':
            tetris()
        elif choice == '11':
            pong_vs_ai()
        elif choice == '12':
            tennis_vs_ai()
        elif choice == '13':
            print("Goodbye!")
            break
        else:
            print("Invalid option. Please select 1-13.\n")

if __name__ == "__main__":
    main_menu()
